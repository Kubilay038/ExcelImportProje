﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Excel;

namespace ExcelVeri
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataSet ds;
        private void btnAc_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Excel|*.xls", ValidateNames = true })
            {
                if (ofd.ShowDialog()==DialogResult.OK)
                {
                    FileStream fs = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read);
                    IExcelDataReader okuyucu = ExcelReaderFactory.CreateBinaryReader(fs);
                    okuyucu.IsFirstRowAsColumnNames = true;
                    ds = okuyucu.AsDataSet();
                    cboSayfa.Items.Clear();
                    foreach (DataTable dt in ds.Tables)
                        cboSayfa.Items.Add(dt.TableName);
                    okuyucu.Close();
                    
                }
            }
        }

        private void cboSayfa_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView.DataSource = ds.Tables[cboSayfa.SelectedIndex];
        }
    }
}
